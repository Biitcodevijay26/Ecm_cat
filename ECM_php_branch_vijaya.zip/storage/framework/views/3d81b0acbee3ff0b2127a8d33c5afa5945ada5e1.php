

<?php $__env->startSection('page_level_css'); ?>
<!--- Custom Style CSS -->
<link href="<?php echo e(url('theme-asset/css/custom_style.css')); ?>" rel="stylesheet"/>
<link rel="stylesheet" href="<?php echo e(url('novnc/app/styles/base.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('novnc/app/styles/input.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
$company_login_id = session()->get('company_login_id');
$adminRoleId = \Config::get('constants.roles.Master_Admin');
?>
<!--app-content open-->
<div class="main-content app-content mt-0">
    <div class="side-app">
        <!-- CONTAINER -->
        <div class="main-container container-fluid">
            <!-- PAGE-HEADER -->
            <div class="page-header d-none">
                <div>
                    <h1 class="page-title"><?php echo e($title); ?></h1>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
                    </ol>
                </div>
                <div class="ms-auto pageheader-btn">
                    
                </div>
            </div>
            <!-- PAGE-HEADER END -->

            <!-- ROW-Buttons Start -->
            <div class="row mb-1">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row d-flex justify-content-left">

                                <?php if ($company_login_id) : ?>
                                    <a href="<?php echo e(url('/company/'.$company_login_id.'/device_details/'.$id)); ?>" class="btn bg-color-default text-black device-btn-width device-btn-text me-2 mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/dashboard-icon.png')); ?>" alt="dashbord-icon"> </span> Dashboard
                                    </a>

                                    <a href="<?php echo e(url('/company/'.$company_login_id.'/battery_details/'.$id)); ?>" class="btn bg-color-default text-black device-btn-width device-btn-text me-2 mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/battry-icon.png')); ?>" alt="battery-icon"> </span> Battery
                                    </a>

                                    <a href="<?php echo e(url('/company/'.$company_login_id.'/edit-device/'.$id)); ?>" class="btn bg-color-default text-black device-btn-width device-btn-text me-2 mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/edit-icon.png')); ?>" alt="edit-device-icon"> </span> Edit POWRBANK
                                    </a>

                                    <a href="<?php echo e(url('/company/'.$company_login_id.'/charts/'.$id)); ?>" class="btn bg-color-default text-black device-btn-width device-btn-text me-2 mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/chart-icon.png')); ?>" alt="view-chart-icon"> </span> View Chart
                                    </a>

                                    <a href="javascript:void(0);" class="btn bg-color-default text-black device-btn-width device-btn-text me-2 machine_verified_btn d-none mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/verified-icon.png')); ?>" alt="verify-machine-icon"> </span> Verify Machine
                                    </a>

                                    <?php if(auth()->guard('admin')->user()->role_id == $adminRoleId) : ?>

                                        <a href="<?php echo e(url('/company/'.$company_login_id.'/remort-access/'.$id)); ?>" class="btn bg-color-default text-black  device-btn-width device-btn-text me-2 remort_access_btn mb-2 d-none" style="width:260px !important">
                                            <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/remort-icon.png')); ?>" alt="remort-access-icon"> </span> Remote Access Setting
                                        </a>

                                        <?php endif; ?>
                                        <a href="<?php echo e(url('/company/'.$company_login_id.'/remote-access-view/'.$id)); ?>" class="btn bg-color-black text-white device-btn-width device-btn-text me-2 remort_access_btn mb-2">
                                            <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/remort-icon.png')); ?>" alt="remort-access-icon"> </span> Remote Access
                                        </a>

                                <?php else : ?>
                                    <a href="<?php echo e(url('/device_details/'.$id)); ?>" class="btn bg-color-default text-black device-btn-width device-btn-text me-2 mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/dashboard-icon.png')); ?>" alt="dashbord-icon"> </span> Dashboard
                                    </a>

                                    <a href="<?php echo e(url('/battery_details/'.$id)); ?>" class="btn bg-color-default text-black device-btn-width device-btn-text me-2 mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/battry-icon.png')); ?>" alt="battery-icon"> </span> Battery
                                    </a>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('DeviceManagementEdit')): ?>
                                    <a href="<?php echo e(url('/edit-device/'.$id)); ?>" class="btn bg-color-default text-black device-btn-width device-btn-text me-2 mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/edit-icon.png')); ?>" alt="edit-device-icon"> </span> Edit POWRBANK
                                    </a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ChartView')): ?>
                                    <a href="<?php echo e(url('/charts/'.$id)); ?>" class="btn bg-color-default text-black device-btn-width device-btn-text me-2 mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/chart-icon.png')); ?>" alt="view-chart-icon"> </span> View Chart
                                    </a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('LiveView')): ?>
                                    <a href="javascript:void(0);" class="btn bg-color-default text-black device-btn-width device-btn-text me-2 machine_verified_btn d-none mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/verified-icon.png')); ?>" alt="verify-machine-icon"> </span> Verify Machine
                                    </a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('RemoteAccessView')): ?>
                                    <a href="<?php echo e(url('/remote-access-view/'.$id)); ?>" class="btn bg-color-black text-white device-btn-width device-btn-text me-2 remort_access_btn mb-2">
                                        <span> <img class="device-btn-icon" src="<?php echo e(url('theme-asset/images/icon/remort-icon.png')); ?>" alt="remort-access-icon"> </span> Remote Access
                                    </a>
                                    <?php endif; ?>

                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ROW-Buttons Close -->

            <!-- ROW-1 OPEN -->
             <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12">
                    <div class="card mt-2">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e($title); ?> Info</h3>
                        </div>
                        <div class="card-body">
                            <h3 class="error"> <?php echo e($sessionError); ?> </h3>
                        </div>
                        <div class="card-footer text-end">
                        </div>
                    </div>
                </div>
            </div>
            <!-- ROW-1 CLOSED -->

        </div>
         <!-- CONTAINER END -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_level_js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout_admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ECM_php_branch_vijaya\resources\views/dwservice/dwservice_error.blade.php ENDPATH**/ ?>