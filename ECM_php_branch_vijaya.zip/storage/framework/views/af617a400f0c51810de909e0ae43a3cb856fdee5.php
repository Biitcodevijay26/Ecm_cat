

<?php $__env->startSection('page_level_css'); ?>
<!--- Custom Style CSS -->
<link href="<?php echo e(url('theme-asset/css/custom_style.css')); ?>" rel="stylesheet"/>
<style>
     .dataTables_paginate  {
        float: right;
    }
    .dataTables_filter, .dataTables_info22, .dataTables_length { display: none; }
    .table td, .table th {
        padding: .75rem 0.75rem;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!--app-content open-->
<div class="main-content app-content mt-0">
    <div class="side-app">
        <!-- CONTAINER -->
        <div class="main-container container-fluid">
                <!-- PAGE-HEADER -->
            <div class="page-header">
                <div>
                    <h1 class="page-title"><?php echo e($heading); ?></h1>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/agent')); ?>"><?php echo e($module); ?></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($heading); ?></li>
                    </ol>
                </div>
                <div class="ms-auto pageheader-btn">
                    
                </div>
            </div>
            <!-- PAGE-HEADER END -->

            <!-- ROW-1 OPEN -->
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e($heading); ?> Info</h3>
                            <div class="page-options d-flex float-end">
                                
                                
                                
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered text-nowrap border-bottom yajra-datatable w-100">
                                    <thead>
                                        <tr>
                                            <th>SN</th>
                                            <th class="wd-15p border-bottom-0">Company Name</th>
                                            <th class="wd-15p border-bottom-0">Agent Name</th>
                                            <th class="wd-15p border-bottom-0">Agent ID</th>
                                            <th class="wd-15p border-bottom-0">Agent Install Code</th>
                                            <th class="wd-15p border-bottom-0">Description</th>
                                            <th class="wd-15p border-bottom-0">Used</th>
                                            <th class="wd-15p border-bottom-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ROW-1 CLOSED -->
        </div>
         <!-- CONTAINER END -->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_level_js'); ?>

<!-- Custom Jquery Validation -->
<script src=" <?php echo e(url('theme-asset/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script>
     $(document).ready(function() {
        var company_agent_id = "<?php echo e($id ?? ''); ?>";
         console.log("company id",company_agent_id);
        $('.select2').select2({});
        $(document).on('select2:open', () => {
            document.querySelector('.select2-search__field').focus();
        });
        var tableRx = $('.yajra-datatable').DataTable({
            processing: true,
            serverSide: true,
            stateSave: true,
            ajax: {
                url: "<?php echo e(url('get-agent-details')); ?>",
                data: function (d) {
                    // d.seacrh_name = $('input[name=seacrh_name]').val();
                    d.company_agent_id = "<?php echo e($id ?? ''); ?>";
                    console.log(d.company_agent_id);
                }
            },
            oLanguage: {sProcessing: "<div id='loaderDB'></div>"},
            aaSorting: [[1, 'desc']],
            columns: [

                {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {data: 'company_name', name: 'company_name',orderable: true, searchable: false},
                {data: 'name', name: 'name',orderable: true, searchable: false },
                {data: 'agent_id', name: 'agent_id',orderable: true, searchable: false },
                {data: 'install_code', name: 'install_code',orderable: true, searchable: false},
                {data: 'description', name: 'description',orderable: true, searchable: false},
                {data: 'used', name: 'used',orderable: true, searchable: false},
                // {data: 'created_at', name: 'created_at',orderable: true, searchable: false},
                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                },
            ],

        });

        $(document).on('click', '.btnSearch', function(e) {
            tableRx.draw();
            e.preventDefault();
        });

        $(document).on('click', '.deleteAgent', function(e) {
            var _this = $(this);
            var agent_detail_id = _this.attr('data-id');
            if(agent_detail_id && company_agent_id){
                var result = confirm("Are you sure you want to delete this Agent?");
                if (result) {
                    $.ajax({
                        url: '<?php echo e(url("delete-agents")); ?>',
                        type: "POST",
                        data:  {agent_detail_id:agent_detail_id,company_agent_id:company_agent_id},
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(data) {
                            try {
                                data = JSON.parse(data);
                            } catch(e){}
                            if(data.status == 'true')
                            {
                                $.growl.notice({
                                    title: "Success",
                                    message: data.response_msg
                                });
                                if(data.redirect_main_screen == 'true'){
                                    // Redirect Main screen
                                    location = "<?php echo e(url('/agent')); ?>";
                                } else {
                                    tableRx.ajax.reload( null, false );
                                }

                            } else {
                                $.growl.error({
                                    message: data.response_msg
                                });
                            }
                        }
                    });
                }
            } else {
                $.growl.error({
                    message: "Somthing want wrong..!"
                });
            }
        });

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout_admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ECM_php_branch_vijaya\resources\views/agent/view_agent.blade.php ENDPATH**/ ?>