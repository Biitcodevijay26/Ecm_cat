

<?php $__env->startSection('page_level_css'); ?>
<!--- Custom Style CSS -->
<link href="<?php echo e(url('theme-asset/css/custom_style.css')); ?>" rel="stylesheet"/>
<style>
     .dataTables_paginate  {
        float: right;
    }
    .dataTables_filter, .dataTables_info22, .dataTables_length { display: none; }
    .table td, .table th {
        padding: .75rem 0.75rem;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!--app-content open-->
<div class="main-content app-content mt-0">
    <div class="side-app">
        <!-- CONTAINER -->
        <div class="main-container container-fluid">
                <!-- PAGE-HEADER -->
            <div class="page-header">
                <div>
                    <h1 class="page-title"><?php echo e($heading); ?></h1>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($heading); ?></li>
                    </ol>
                </div>
                <div class="ms-auto pageheader-btn">
                    
                </div>
            </div>
            <!-- PAGE-HEADER END -->

            <!-- ROW-1 OPEN -->
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e($heading); ?> Info</h3>
                            <div class="page-options d-flex float-end">
                                
                                <select class="form-select me-2" aria-label="Default select example" name="seacrh_name" id="seacrh_name">
                                    <option selected value="">Select Company</option>
                                    <?php if($getCompany): ?>
                                    <?php $__currentLoopData = $getCompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($company->id ?? ''); ?>"><?php echo e($company->company_name ?? ''); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <?php endif; ?>
                                </select>
                                <button type="button" class="btnSearch btn btn-info pull-right me-2" title="Click to Search"><i class="fe fe-search"></i></button>
                                <a href="<?php echo e(url('/channel-add')); ?>" class="btn bg-add-btn pull-right" title="Click to add"><i class="fe fe-plus"></i></a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered text-nowrap border-bottom yajra-datatable w-100">
                                    <thead>
                                        <tr>

                                            <th>SN</th>
                                            <th class="wd-15p border-bottom-0">Company Name</th>
                                            
                                            <th class="wd-15p border-bottom-0">Channel ID</th>
                                            <th class="wd-15p border-bottom-0">Assign Count</th>
                                            
                                            <th class="wd-15p border-bottom-0">Created At</th>
                                            <th class="wd-25p border-bottom-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ROW-1 CLOSED -->
        </div>
         <!-- CONTAINER END -->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_level_js'); ?>

<!-- Custom Jquery Validation -->
<script src=" <?php echo e(url('theme-asset/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script>
     $(document).ready(function() {
        $('.select2').select2({});
        $(document).on('select2:open', () => {
            document.querySelector('.select2-search__field').focus();
        });
        var tableRx = $('.yajra-datatable').DataTable({
            processing: true,
            serverSide: true,
            stateSave: true,
            ajax: {
                url: "<?php echo e(url('get-channel')); ?>",
                data: function (d) {
                    d.seacrh_name = $('select[name=seacrh_name]').val();
                }
            },
            oLanguage: {sProcessing: "<div id='loaderDB'></div>"},
            aaSorting: [[1, 'desc']],
            columns: [

                {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {data: 'company_name', name: 'company_name',orderable: true, searchable: false},
                // {data: 'number_of_channel', name: 'number_of_channel',orderable: true, searchable: false },
                {data: 'channel_ids', name: 'channel_ids',orderable: false, searchable: false },
                {data: 'assign_counts', name: 'assign_counts',orderable: false, searchable: false },
                // {data: 'status', name: 'status',orderable: true, searchable: false},
                {data: 'created_at', name: 'created_at',orderable: true, searchable: false},
                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                },
            ],

        });

        // $(document).on('click', '.activeInactiveCompanyAgent', function() {
        //     var _this = $(this);
        //     var id = _this.attr('data-id');
        //     $('label.error').remove();
        //     $('label.success_msg').remove();
        //     $('.alert-outline-success').remove();

        //         $.ajax({
        //             url: '<?php echo e(url("active-company-agent")); ?>',
        //             type: "POST",
        //             data:  {id:id},
        //             headers: {
        //                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //             },
        //             success: function(data) {
        //                 tableRx.ajax.reload( null, false );
        //             }
        //         });
        // });

        $(document).on('click', '.btnSearch', function(e) {
            tableRx.draw();
            e.preventDefault();
        });

        $(document).on('click', '.deleteChannel', function() {
            var _this = $(this);
            var id = _this.attr('data-id');
            var result = confirm("Are you sure you want to delete this channel?");
            if (result) {
                if(id){
                    $.ajax({
                        url: '<?php echo e(url("remove-channel")); ?>',
                        type: "POST",
                        data:  {id:id},
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(data) {
                            try {
                                data = JSON.parse(data);
                            } catch(e){}
                            if(data.status == 'true')
                            {
                                $.growl.notice({
                                    title: "Success",
                                    message: "Succesfully deleted."
                                });
                                tableRx.ajax.reload( null, false );

                            } else {
                                $.growl.error({
                                    message: data.response_msg
                                });
                            }
                        }
                    });
                }
            }

        });

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout_admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ECM_php_branch_vijaya\resources\views/channel/list.blade.php ENDPATH**/ ?>