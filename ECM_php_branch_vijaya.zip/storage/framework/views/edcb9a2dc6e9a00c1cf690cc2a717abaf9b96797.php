<!-- BEGIN: Main Menu-->

<?php if( isCompanyLogin() == 'true'): ?>
     <?php echo $__env->make('front.layout_admin.menu.company_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
     <?php echo $__env->make('front.layout_admin.menu.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\ECM_php_branch_vijaya\resources\views/front/layout_admin/menu.blade.php ENDPATH**/ ?>