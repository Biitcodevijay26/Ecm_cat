<!doctype html>
<html lang="en" dir="ltr">
  <head>

		<!-- META DATA -->
		<meta charset="UTF-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="<?php echo e(config('app.name')); ?>">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
		<meta name="author" content="<?php echo e(config('app.name')); ?>">
		<meta name="keywords" content="">

		<!-- FAVICON -->
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('theme-asset/images/brand/favicon.ico')); ?>" />

		<!-- TITLE -->
		<title><?php echo e(config('app.name')); ?></title>

		<!-- BOOTSTRAP CSS -->
		<link id="style" href="<?php echo e(url('theme-asset/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />

		<!-- STYLE CSS -->
		<link href="<?php echo e(url('theme-asset/css/style.css')); ?>" rel="stylesheet"/>
		<link href="<?php echo e(url('theme-asset/css/plugins.css')); ?>" rel="stylesheet"/>

		<!--- FONT-ICONS CSS -->
		<link href="<?php echo e(url('theme-asset/css/icons.css')); ?>" rel="stylesheet"/>

        <!--- Custom Style CSS -->
		<link href="<?php echo e(url('theme-asset/css/custom_style.css')); ?>" rel="stylesheet"/>

        <?php echo $__env->yieldContent('page_level_css'); ?>
        <style>
	    	.wrap-input100 {
	    		margin-bottom:0 !important;
	    	 }
        </style>
	</head>

	<body class="login-img">

		<!-- BACKGROUND-IMAGE -->
		<div>

			<!-- GLOABAL LOADER -->
			<div id="global-loader">
				<img src="<?php echo e(url('theme-asset/images/loader.svg')); ?>" class="loader-img" alt="Loader">
			</div>
			<!-- /GLOABAL LOADER -->

			<!-- PAGE -->
			<div class="page login-page">
				<div>
				    <!-- CONTAINER OPEN -->
					<div class="col col-login mx-auto mt-7">
						<div class="text-center">
							<img src="<?php echo e(url('theme-asset/images/brand/logo.png')); ?>" class="header-brand-img" alt=""> 
                            
						
						</div>
					</div>
					<div class="container-login100">
						<div class="wrap-login100 p-0">
							<div class="card-body">
								<form class="login100-form validate-form" action="<?php echo e(url('admin-login')); ?>" method="POST" id="admin-login-form">
									<?php echo csrf_field(); ?>
									<span class="login100-form-title" Style="font-weight:bold">
										SUPER ADMIN LOGIN
									</span>
                                    <label class="label-margin" for="email">Email <span class="text-danger"> *</span> </label>
									<div class="wrap-input100 validate-input">
										<input class="input100 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="email" placeholder="Email">
										<span class="focus-input100"></span>
										<span class="symbol-input100">
											<i class="zmdi zmdi-email" aria-hidden="true"></i>
										</span>
									</div>
                                    <div class="error-email"></div>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<div class="bg-danger-transparent-2 text-danger px-4 py-2 br-3 mb-4" role="alert"><?php echo e($message); ?></div>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <label class="label-margin mt-2" for="password">Password <span class="text-danger"> *</span> </label>
                                    <div class="wrap-input100 validate-input mt-2">
										<input class="input100 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password" placeholder="Password">
										<span class="focus-input100"></span>
										<span class="symbol-input100">
											<i class="zmdi zmdi-lock" aria-hidden="true"></i>
										</span>
									</div>
                                    <div class="error-password"></div>
									<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<div class="bg-danger-transparent-2 text-danger px-4 py-2 br-3 mb-4" role="alert"><?php echo e($message); ?></div>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

									
									<div class="container-login100-form-btn">
										<button href="<?php echo e(url('admin/dashboard')); ?>" class="login100-form-btn btn-success" Style="font-weight:bold;width:150px;border-radius:50px">
										<img src="<?php echo e(url('theme-asset/images/brand/logo1.png')); ?>" width="20" height="20" Style="margin-right: 10px">
										LOGIN
				                       </button>
									</div>
									
								</form>
							</div>
							
						</div>
					</div>
					<div class="text-center">
				        <img src="<?php echo e(url('theme-asset/images/brand/logo2.png')); ?>" class="header-brand-img" alt="">
			        </div>
					<!-- CONTAINER CLOSED -->
				</div>
			</div>
			<!-- End PAGE -->
		</div>
		<!-- BACKGROUND-IMAGE CLOSED -->

		<!-- JQUERY JS -->
		<script src="<?php echo e(url('theme-asset/js/jquery.min.js')); ?>"></script>

		<!-- BOOTSTRAP JS -->
		<script src="<?php echo e(url('theme-asset/plugins/bootstrap/js/popper.min.js')); ?>"></script>
		<script src="<?php echo e(url('theme-asset/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

		<!-- SPARKLINE JS -->
		<script src="<?php echo e(url('theme-asset/js/jquery.sparkline.min.js')); ?>"></script>

		<!-- CHART-CIRCLE JS -->
		<script src="<?php echo e(url('theme-asset/js/circle-progress.min.js')); ?>"></script>

		<!-- Perfect SCROLLBAR JS-->
		<script src="<?php echo e(url('theme-asset/plugins/p-scroll/perfect-scrollbar.js')); ?>"></script>

		<!-- INPUT MASK JS -->
		<script src="<?php echo e(url('theme-asset/plugins/input-mask/jquery.mask.min.js')); ?>"></script>

        <!-- Color Theme js -->
        <script src="<?php echo e(url('theme-asset/js/themeColors.js')); ?>"></script>

        <!-- swither styles js -->
        <script src="<?php echo e(url('theme-asset/js/swither-styles.js')); ?>"></script>

        <!-- CUSTOM JS -->
        <script src=" <?php echo e(url('theme-asset/js/custom.js')); ?>"></script>

         <!-- Custom Jquery Validation -->
         <script src=" <?php echo e(url('theme-asset/jquery-validation/jquery.validate.min.js')); ?>"></script>

         <script>
             $(document).ready(function($) {

                 $('#admin-login-form').validate({
                       ignore: "",
                       //errorElement: 'div',
                       //errorClass: "invalid-feedback",
                       rules: {
                           email: {
                               required: true,
                               email: true
                           },
                           password: {
                               required: true,
                           }

                       },
                       messages: {

                       },
                       // errorElement: "div",
                       errorPlacement: function(error, element) {
                           if(element.attr('name') == "email")
                           {
                               error.insertBefore('.error-email');
                           } else if(element.attr('name') == "password"){
                               error.insertBefore('.error-password');
                           }  else {
                               error.insertAfter(element);
                           }
                       },
                       submitHandler: function (form) {
                         form.submit();
                       }

                   });
             });
         </script>

	</body>
</html>
<?php /**PATH C:\laragon\www\ECM_php_branch_vijaya\resources\views/admin-login.blade.php ENDPATH**/ ?>