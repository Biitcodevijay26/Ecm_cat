<!doctype html>
<html lang="en" dir="ltr">

    <head>

        <!-- META DATA -->
        <meta charset="UTF-8">
        <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="<?php echo e(config('app.name')); ?>">
        <meta name="author" content="<?php echo e(config('app.name')); ?>">
        <meta name="keywords" content="">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <meta property="og:title" content="My saving" />
        <!-- FAVICON -->
        <!-- <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('theme-asset/images/brand/favicon.ico')); ?>" /> -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('theme-asset/images/logo_dark.ico')); ?>" />
        <!-- TITLE -->
        <title><?php echo e(config('app.name')); ?></title>

        <!-- BOOTSTRAP CSS -->
        <link id="style" href="<?php echo e(url('theme-asset/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />

        <!-- STYLE CSS -->
        <link href="<?php echo e(url('theme-asset/css/style.css')); ?>" rel="stylesheet"/>
		<link href="<?php echo e(url('theme-asset/css/plugins.css')); ?>" rel="stylesheet"/>

        <!--- FONT-ICONS CSS -->
        <link href="<?php echo e(url('theme-asset/css/icons.css')); ?>" rel="stylesheet"/>
        <style>
            .head-alert {
                padding: 0.1rem 1.25rem !important;
            }
            .swal2-container{
                z-index:9999 !important;
            }
        </style>
        <?php echo $__env->yieldContent('page_level_css'); ?>

    </head>
    <?php
        isCompanyLogin();
        $company_login_id    = session()->get('company_login_id');
        $company_login_name  = session()->get('company_login_name');
        $unreadNotifications = getNotification();
        $unreadCounts        = getNotificationCounts();

    ?>
    <body class="app sidebar-mini ltr light-mode">

        <!-- GLOBAL-LOADER -->
        <div id="global-loader">
            <img src="<?php echo e(url('theme-asset/images/loader.svg')); ?>" class="loader-img" alt="Loader">
        </div>
        <!-- /GLOBAL-LOADER -->

         <!-- PAGE -->
         <div class="page">
            <div class="page-main">
                <!-- app-Header -->
                <div class="app-header header sticky">
                    <div class="container-fluid main-container">
                        <div class="d-flex align-items-center">
                            <a aria-label="Hide Sidebar" class="app-sidebar__toggle" data-bs-toggle="sidebar" href="javascript:void(0);"></a>
                            <div class="responsive-logo">
                                <a href="dashboard" class="header-logo">
                                    <img src="<?php echo e(url('theme-asset/images/brand/logo_dark.png')); ?>" class="mobile-logo logo-1" alt="logo">
                                    <img src="<?php echo e(url('theme-asset/images/brand/logo_dark.png')); ?>" class="mobile-logo dark-logo-1" alt="logo">
                                </a>
                            </div>
                            <!-- sidebar-toggle-->
                            <a class="logo-horizontal " href="dashboard">
                                <img src="<?php echo e(url('theme-asset/images/brand/logo_dark.png')); ?>" class="header-brand-img desktop-logo" alt="logo">
                                <img src="<?php echo e(url('theme-asset/images/brand/logo_dark.png')); ?>" class="header-brand-img light-logo1"
                                    alt="logo">
                            </a>
                            <!-- LOGO -->
                            <!--<div class="main-header-center ms-3 d-none d-lg-block">
                                <input class="form-control" placeholder="Search for anything..." type="search"> <button class="btn"><i class="fa fa-search" aria-hidden="true"></i></button>
                            </div>-->
                            <div class="d-flex order-lg-2 ms-auto header-right-icons">
                                <!-- SEARCH -->
                                <button class="navbar-toggler navresponsive-toggler d-lg-none ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent-4" aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
                                        <span class="navbar-toggler-icon fe fe-more-vertical text-dark"></span>
                                    </button>
                                <div class="navbar navbar-collapse responsive-navbar p-0">
                                    <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
                                        <div class="d-flex order-lg-2">
                                            <div class="dropdown d-block d-lg-none">
                                                <a href="javascript:void(0);" class="nav-link icon" data-bs-toggle="dropdown">
                                                    <i class="fe fe-search"></i>
                                                </a>
                                                <div class="dropdown-menu header-search dropdown-menu-start">
                                                    <div class="input-group w-100 p-2">
                                                        <input type="text" class="form-control" placeholder="Search....">
                                                        <div class="input-group-text btn btn-primary">
                                                            <i class="fa fa-search" aria-hidden="true"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
												<a href="dashboard" class="header-logo">
                                                    <img src="<?php echo e(url('theme-asset/images/brand/logo_dark1.png')); ?>" class="mobile-logo logo-1" style="height:40px;width:170px" alt="logo">
                                                </a>													 
                                            <?php if ($company_login_id) : ?>
                                            <div class="dropdown text-center selector profile-1">
                                                <a href="<?php echo e(url('/company')); ?>" class="nav-link leading-none d-flex" title="Click to Switch Company">
                                                    <span class="d-none d-xl-block alert alert-success rounded-pill head-alert">
                                                        <h5 class="text-dark pt-2">Logged in as &nbsp <strong class="text-capitalize me-1"> <?php echo $company_login_name ?> </strong> <i class="fe fe-repeat" id="myHome"></i> </h5>
                                                    </span>
                                                </a>
                                            </div>
                                            <?php endif; ?>
                                            
                                            <!-- Theme-Layout -->
                                            <div class="dropdown d-md-flex">
                                                <a class="nav-link icon full-screen-link nav-link-bg">
                                                    <i class="fe fe-minimize fullscreen-button" id="myvideo"></i>
                                                </a>
                                            </div>
                                            <!-- FULL-SCREEN -->
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                                            <?php if(!$company_login_id): ?>
                                            <div class="dropdown d-md-flex notifications">
                                                <a class="nav-link icon" data-bs-toggle="dropdown"><i class="fe fe-bell"></i>
                                                    <?php if($unreadNotifications && count($unreadNotifications) > 0): ?>
                                                        <span class="pulse"></span>
                                                    <?php endif; ?>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow ">
                                                    <div class="drop-heading border-bottom">
                                                        <div class="d-flex">
                                                            <h6 class="mt-1 mb-0 fs-16 fw-semibold">You have Notification</h6>
                                                            <div class="ms-auto">

                                                                <span class="badge bg-success rounded-pill unreadNotifCount"><?php echo e($unreadCounts ?? 0); ?></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="notifications-menu">
                                                        <?php
                                                            if($unreadNotifications && count($unreadNotifications) > 0) :
                                                            foreach ($unreadNotifications as $key => $notification) :
                                                        ?>

                                                        <a class="dropdown-item d-flex single_read_mark" data-id="<?php echo e($notification->id); ?>" href="<?php echo e(url('/user-edit/'.$notification->user_id)); ?>">
                                                            <div class="me-3 notifyimg  bg-primary-gradient brround box-shadow-primary">
                                                                <i class="fe fe-user"></i>
                                                            </div>
                                                            <div class="mt-1 wd-80p">
                                                                <h5 class="notification-label mb-1">New User Register</h5>
                                                                <p class="small mb-0"><?php echo e($notification->user->full_name ?? ''); ?></p>
                                                                <span class="notification-subtext"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                                                            </div>
                                                        </a>

                                                        <?php endforeach; endif; ?>
                                                    </div>
                                                    <div class="dropdown-divider m-0"></div>
                                                    <a href="<?php echo e(url('/notification-list')); ?>" class="dropdown-item text-center p-3 text-muted">View all Notification</a>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                            <!-- NOTIFICATIONS -->
                                            
                                            <!-- MESSAGE-BOX -->
                                            <div class="dropdown d-md-flex profile-1">
                                                <a href="javascript:void(0);" data-bs-toggle="dropdown" class="nav-link leading-none d-flex px-1">
                                                    <span>
                                                            <img src="<?php echo e(url('theme-asset/images/user.png')); ?>" alt="profile-user" class="avatar  profile-user brround cover-image">
                                                        </span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                    <div class="drop-heading">
                                                        <div class="text-center">
                                                            <h5 class="text-dark mb-0">
                                                                <?php if(Auth::guard('admin')->check() == 1): ?>
                                                                <?php if(isset(Auth::guard('admin')->user()->first_name)): ?>
                                                                    <?php echo e(Auth::guard('admin')->user()->first_name .' '. Auth::guard('admin')->user()->last_name); ?>

                                                                <?php endif; ?>
                                                                <?php endif; ?>
                                                             </h5>
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="dropdown-divider m-0"></div>
                                                    
                                                    <a class="dropdown-item" href="<?php echo e(url('logout')); ?>">
                                                        <i class="dropdown-icon fe fe-alert-circle"></i> Sign out
                                                    </a>
                                                </div>
                                            </div>
                                            
                                            <!-- SIDE-MENU -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /app-Header -->




<?php /**PATH C:\laragon\www\ECM_php_branch_vijaya\resources\views/front/layout_admin/header.blade.php ENDPATH**/ ?>